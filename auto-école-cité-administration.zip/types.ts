
export type Language = 'fr' | 'ar';

export interface Testimonial {
  name: string;
  feedback: string;
  rating: number;
}
