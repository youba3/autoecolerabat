
import React from 'react';
import type { Language } from '../types';

interface ContactProps {
  lang: Language;
  content: {
    title: string;
    subtitle: string;
    address: string;
    address_val: string;
    phone: string;
    phone_val: string;
    email: string;
    email_val: string;
    form: {
      name: string;
      email: string;
      message: string;
      submit: string;
    };
    map_title: string;
  };
}

const ContactSection: React.FC<ContactProps> = ({ lang, content }) => {
  return (
    <section id="contact" className="py-20 bg-lightBlue">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary">{content.title}</h2>
          <p className="text-lg text-gray-600 mt-2">{content.subtitle}</p>
          <div className="w-24 h-1 bg-accent mx-auto mt-4"></div>
        </div>
        <div className="grid lg:grid-cols-2 gap-12">
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <form>
              <div className="mb-4">
                <label htmlFor="name" className="block text-gray-700 font-semibold mb-2 ltr:text-left rtl:text-right">{content.form.name}</label>
                <input type="text" id="name" name="name" className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div className="mb-4">
                <label htmlFor="email" className="block text-gray-700 font-semibold mb-2 ltr:text-left rtl:text-right">{content.form.email}</label>
                <input type="email" id="email" name="email" className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
              </div>
              <div className="mb-6">
                <label htmlFor="message" className="block text-gray-700 font-semibold mb-2 ltr:text-left rtl:text-right">{content.form.message}</label>
                <textarea id="message" name="message" rows={5} className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"></textarea>
              </div>
              <button type="submit" className="w-full bg-accent text-white font-bold py-3 px-6 rounded-md hover:bg-orange-700 transition-colors duration-300">
                {content.form.submit}
              </button>
            </form>
          </div>
          <div className="ltr:text-left rtl:text-right">
            <div className="mb-6">
              <h3 className="text-xl font-bold text-primary mb-2">{content.address}</h3>
              <p className="text-gray-600">{content.address_val}</p>
            </div>
            <div className="mb-6">
              <h3 className="text-xl font-bold text-primary mb-2">{content.phone}</h3>
              <p className="text-gray-600">{content.phone_val}</p>
            </div>
            <div className="mb-6">
              <h3 className="text-xl font-bold text-primary mb-2">{content.email}</h3>
              <p className="text-gray-600">{content.email_val}</p>
            </div>
             <div className="mt-8">
                <h3 className="text-xl font-bold text-primary mb-2">{content.map_title}</h3>
                <div className="aspect-w-16 aspect-h-9">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3308.199049755491!2d-6.84981238478641!3d34.01325178062039!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xda76b871f50c529%3A0x2d3a3d0f0e5b5c1a!2sRabat!5e0!3m2!1sen!2sma!4v1620847265809!5m2!1sen!2sma" 
                        width="100%" 
                        height="300" 
                        style={{border:0}} 
                        allowFullScreen={true}
                        loading="lazy"
                        className="rounded-lg shadow-md"
                    ></iframe>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
