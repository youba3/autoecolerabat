
import React from 'react';
import type { Language } from '../types';

interface PricingProps {
  lang: Language;
  content: {
    title: string;
    subtitle: string;
    pack1: { name: string; price: string; features: string[]; cta: string; };
    pack2: { name: string; price: string; features: string[]; cta: string; popular?: string; };
    pack3: { name: string; price: string; features: string[]; cta: string; };
  };
}

const CheckIcon = () => (
  <svg className="w-5 h-5 text-green-500 ltr:mr-2 rtl:ml-2 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
  </svg>
);

const PricingCard: React.FC<{ pack: any; isPopular?: boolean }> = ({ pack, isPopular = false }) => (
  <div className={`relative bg-white rounded-lg shadow-lg p-8 flex flex-col text-center border-t-4 ${isPopular ? 'border-accent scale-105' : 'border-primary'}`}>
    {isPopular && (
      <div className="absolute top-0 ltr:-translate-y-1/2 rtl:translate-y-1/2 left-1/2 -translate-x-1/2 bg-accent text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">{pack.popular}</div>
    )}
    <h3 className="text-2xl font-bold text-primary mb-4">{pack.name}</h3>
    <p className="text-4xl font-extrabold text-gray-800 mb-6">{pack.price}</p>
    <ul className="space-y-3 mb-8 flex-grow ltr:text-left rtl:text-right">
      {pack.features.map((feature: string, index: number) => (
        <li key={index} className="flex items-center">
          <CheckIcon />
          <span className="text-gray-600">{feature}</span>
        </li>
      ))}
    </ul>
    <a href="#contact" className={`mt-auto text-white font-semibold py-3 px-6 rounded-md hover:opacity-90 transition-opacity duration-300 ${isPopular ? 'bg-accent' : 'bg-primary'}`}>
      {pack.cta}
    </a>
  </div>
);

const PricingSection: React.FC<PricingProps> = ({ lang, content }) => {
  return (
    <section id="pricing" className="py-20 bg-lightBlue">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary">{content.title}</h2>
          <p className="text-lg text-gray-600 mt-2">{content.subtitle}</p>
          <div className="w-24 h-1 bg-accent mx-auto mt-4"></div>
        </div>
        <div className="grid lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <PricingCard pack={content.pack1} />
          <PricingCard pack={content.pack2} isPopular={true} />
          <PricingCard pack={content.pack3} />
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
