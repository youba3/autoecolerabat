
import React from 'react';
import type { Language } from '../types';

interface AboutSectionProps {
  lang: Language;
  content: {
    title: string;
    subtitle: string;
    p1: string;
    p2: string;
    stat1_val: string;
    stat1_label: string;
    stat2_val: string;
    stat2_label: string;
    stat3_val: string;
    stat3_label: string;
  };
}

const AboutSection: React.FC<AboutSectionProps> = ({ lang, content }) => {
  return (
    <section id="about" className="py-20 bg-lightBlue">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary">{content.title}</h2>
          <p className="text-lg text-gray-600 mt-2">{content.subtitle}</p>
          <div className="w-24 h-1 bg-accent mx-auto mt-4"></div>
        </div>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="ltr:text-left rtl:text-right">
            <p className="mb-4 text-gray-700 leading-relaxed">{content.p1}</p>
            <p className="text-gray-700 leading-relaxed">{content.p2}</p>
            <div className="mt-8 grid grid-cols-3 gap-4 text-center">
              <div>
                <span className="block text-3xl font-bold text-accent">{content.stat1_val}</span>
                <span className="block text-sm text-gray-500">{content.stat1_label}</span>
              </div>
              <div>
                <span className="block text-3xl font-bold text-accent">{content.stat2_val}</span>
                <span className="block text-sm text-gray-500">{content.stat2_label}</span>
              </div>
              <div>
                <span className="block text-3xl font-bold text-accent">{content.stat3_val}</span>
                <span className="block text-sm text-gray-500">{content.stat3_label}</span>
              </div>
            </div>
          </div>
          <div>
            <img src="https://picsum.photos/seed/instructor/600/400" alt="Driving instructor with student" className="rounded-lg shadow-2xl w-full h-auto" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
