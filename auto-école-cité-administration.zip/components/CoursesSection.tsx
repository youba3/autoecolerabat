
import React from 'react';
import type { Language } from '../types';

interface CourseProps {
  lang: Language;
  content: {
    title: string;
    subtitle: string;
    car: {
      title: string;
      description: string;
      features: string[];
    };
    moto: {
      title: string;
      description: string;
      features: string[];
    };
    cta: string;
  };
}

const CarIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 17H5.5a2 2 0 01-2-1.79V11a2 2 0 012-2h1.29a1 1 0 00.9-.55L11 6h2l1.81 1.45a1 1 0 00.9.55H18.5a2 2 0 012 2v4.21a2 2 0 01-2 1.79H13m-2-4v4m-2 0h4" />
  </svg>
);

const MotoIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-accent" viewBox="0 0 24 24" fill="currentColor">
    <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8a1 1 0 001 1h1a1 1 0 001-1v-1h12v1a1 1 0 001 1h1a1 1 0 001-1v-8l-2.08-5.99zM6.5 16a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm11 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3zM5 11l1.5-4.5h11L19 11H5z" />
  </svg>
);

const CheckIcon = () => (
  <svg className="w-5 h-5 text-green-500 ltr:mr-2 rtl:ml-2 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
  </svg>
);

const CourseCard: React.FC<{ icon: React.ReactNode; title: string; description: string; features: string[]; cta: string; lang: Language }> = ({ icon, title, description, features, cta, lang }) => (
  <div className="bg-white rounded-lg shadow-lg p-8 flex flex-col hover:shadow-2xl hover:-translate-y-2 transition-all duration-300">
    <div className="flex items-center mb-4">
      {icon}
      <h3 className="text-2xl font-bold text-primary ltr:ml-4 rtl:mr-4">{title}</h3>
    </div>
    <p className="text-gray-600 mb-6 flex-grow">{description}</p>
    <ul className="space-y-3 mb-8 ltr:text-left rtl:text-right">
      {features.map((feature, index) => (
        <li key={index} className="flex items-center">
          <CheckIcon />
          <span>{feature}</span>
        </li>
      ))}
    </ul>
    <a href="#contact" className="mt-auto bg-accent text-white font-semibold py-2 px-6 rounded-md text-center hover:bg-orange-700 transition-colors duration-300">
      {cta}
    </a>
  </div>
);

const CoursesSection: React.FC<CourseProps> = ({ lang, content }) => {
  return (
    <section id="courses" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary">{content.title}</h2>
          <p className="text-lg text-gray-600 mt-2">{content.subtitle}</p>
          <div className="w-24 h-1 bg-accent mx-auto mt-4"></div>
        </div>
        <div className="grid md:grid-cols-2 gap-8">
          <CourseCard
            lang={lang}
            icon={<CarIcon />}
            title={content.car.title}
            description={content.car.description}
            features={content.car.features}
            cta={content.cta}
          />
          <CourseCard
            lang={lang}
            icon={<MotoIcon />}
            title={content.moto.title}
            description={content.moto.description}
            features={content.moto.features}
            cta={content.cta}
          />
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
