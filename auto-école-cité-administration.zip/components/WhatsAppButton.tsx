
import React from 'react';
import type { Language } from '../types';

interface WhatsAppButtonProps {
    lang: Language;
    content: {
        cta: string;
    }
}

const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({ lang, content }) => {
  const phoneNumber = '212600112233'; // Morocco country code + number without +/00
  const message = lang === 'fr' ? 'Bonjour, je voudrais plus d\'informations.' : 'مرحباً، أود الحصول على المزيد من المعلومات.';
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-5 ltr:right-5 rtl:left-5 z-50 bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-transform transform hover:scale-110 flex items-center group"
      aria-label="Contact us on WhatsApp"
    >
      <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.487 5.235 3.487 8.413 0 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 4.315 1.847 6.062l-1.214 4.439 4.533-1.186z" />
        <path d="M18.118 14.732c-.244-.13-.574-.282-.82-.343-.246-.062-.423-.093-.6-.093-.176 0-.353.031-.53.093-.176.063-.396.219-.53.375-.134.156-.268.344-.369.469-.102.125-.203.203-.338.219-.134.016-.282-.015-.43-.062-.148-.047-.71-.266-1.282-.766-.572-.5-1.023-1.082-1.148-1.266-.125-.184-.016-.312.093-.422.094-.093.203-.25.305-.375.102-.125.133-.219.203-.344.069-.125.031-.25-.016-.344-.047-.093-.574-1.375-.736-1.859-.162-.484-.324-.422-.449-.422-.125 0-.25.016-.375.016-.125 0-.282.047-.449.219-.167.172-.649.633-.649 1.562 0 .93.664 1.812.766 1.938.101.125.633.992 1.562 1.406.929.414 1.562.625 1.812.703.25.078.53.063.703.031.176-.031.574-.234.649-.469.075-.234.075-.437.063-.468-.012-.031-.094-.062-.203-.125" />
      </svg>
      <span className="ltr:ml-2 rtl:mr-2 ltr:origin-left rtl:origin-right transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-in-out whitespace-nowrap">{content.cta}</span>
    </a>
  );
};

export default WhatsAppButton;
