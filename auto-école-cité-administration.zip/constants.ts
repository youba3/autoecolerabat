
import type { Testimonial } from './types';

const testimonials: Testimonial[] = [
  { name: 'Fatima Zahra', feedback: "Excellente formation, moniteurs patients et pédagogues. J'ai eu mon permis du premier coup. Merci !", rating: 5 },
  { name: 'Youssef Alaoui', feedback: "Une auto-école sérieuse et professionnelle. Le suivi est personnalisé et les voitures sont neuves.", rating: 5 },
  { name: 'Amine Bennani', feedback: "J'ai passé le permis moto ici. L'instructeur était super, très technique et rassurant. Je recommande vivement.", rating: 4 },
];

const testimonialsAr: Testimonial[] = [
  { name: 'فاطمة الزهراء', feedback: "تكوين ممتاز، المدربون صبورون ومحترفون. حصلت على رخصتي من المحاولة الأولى. شكراً لكم!", rating: 5 },
  { name: 'يوسف علوي', feedback: "مدرسة لتعليم السياقة جادة ومحترفة. المتابعة شخصية والسيارات جديدة.", rating: 5 },
  { name: 'أمين بناني', feedback: "لقد اجتزت رخصة الدراجة النارية هنا. كان المدرب رائعًا، تقنيًا ومطمئنًا للغاية. أوصي به بشدة.", rating: 4 },
];

export const content = {
  fr: {
    header: {
      home: 'Accueil',
      about: 'À propos',
      courses: 'Formations',
      pricing: 'Tarifs',
      testimonials: 'Avis',
      contact: 'Contact',
      langToggle: 'العربية',
    },
    hero: {
      title: 'Votre permis de conduire, notre priorité',
      subtitle: 'Formation de qualité, réussite assurée. Rejoignez l\'Auto-École Cité Administration à Rabat.',
      cta: 'Nos Formations',
    },
    about: {
      title: 'Qui sommes-nous ?',
      subtitle: 'Votre partenaire de confiance pour la conduite',
      p1: 'Fondée sur des principes de professionnalisme et de pédagogie, l\'Auto-École Cité Administration s\'est imposée comme une référence à Rabat. Notre mission est de former des conducteurs responsables et sûrs.',
      p2: 'Avec une équipe de moniteurs certifiés et passionnés, et une flotte de véhicules modernes, nous vous offrons les meilleures conditions pour apprendre à conduire en toute sérénité.',
      stat1_val: '10+',
      stat1_label: 'Années d\'expérience',
      stat2_val: '95%',
      stat2_label: 'Taux de réussite',
      stat3_val: '2000+',
      stat3_label: 'Élèves formés',
    },
    courses: {
      title: 'Nos Formations',
      subtitle: 'Choisissez la formule qui vous convient',
      car: {
        title: 'Permis B (Voiture)',
        description: 'Une formation complète incluant des cours de code intensifs et des leçons de conduite pratiques pour maîtriser votre véhicule.',
        features: ['20h de code', '20h de conduite', 'Examen blanc', 'Suivi personnalisé'],
      },
      moto: {
        title: 'Permis A (Moto)',
        description: 'Apprenez à piloter une moto en toute sécurité avec nos moniteurs spécialisés, sur plateau et en circulation.',
        features: ['Formation théorique', 'Maîtrise du véhicule', 'Conduite en circulation', 'Équipement fourni'],
      },
      cta: 'Plus de détails'
    },
    pricing: {
      title: 'Nos Tarifs',
      subtitle: 'Des formules transparentes et adaptées à vos besoins',
      pack1: {
        name: 'Pack Essentiel',
        price: '2500 DH',
        features: ['Formation Code de la route', '20h de conduite', 'Frais de dossier'],
        cta: 'S\'inscrire',
      },
      pack2: {
        name: 'Pack Confort',
        price: '3000 DH',
        features: ['Pack Essentiel', '4h de conduite supplémentaires', 'Cours de code en ligne'],
        cta: 'S\'inscrire',
        popular: 'Populaire',
      },
      pack3: {
        name: 'Pack Moto',
        price: '2000 DH',
        features: ['Formation théorique spécifique', '15h de conduite (plateau & route)', 'Frais de dossier'],
        cta: 'S\'inscrire',
      },
    },
    testimonials: {
      title: 'Avis de nos clients',
      subtitle: 'Ce qu\'ils pensent de nous',
      reviews: testimonials,
    },
    contact: {
      title: 'Contactez-nous',
      subtitle: 'Nous sommes à votre écoute',
      address: 'Adresse',
      address_val: 'Avenue Mohammed V, Rabat, Maroc',
      phone: 'Téléphone',
      phone_val: '+212 6 00 11 22 33',
      email: 'Email',
      email_val: 'contact@autoecolecite.ma',
      form: {
        name: 'Votre nom',
        email: 'Votre email',
        message: 'Votre message',
        submit: 'Envoyer le message',
      },
      map_title: 'Notre emplacement',
    },
    footer: {
      about: 'L\'Auto-École Cité Administration vous accompagne vers la réussite de votre permis de conduire avec une méthode pédagogique éprouvée et un service de qualité.',
      quick_links: 'Liens rapides',
      social_media: 'Suivez-nous',
      copyright: '© 2024 Auto-École Cité Administration. Tous droits réservés.',
    },
    whatsapp: {
      cta: 'Contactez-nous sur WhatsApp !',
    }
  },
  ar: {
    header: {
      home: 'الرئيسية',
      about: 'من نحن',
      courses: 'تكويناتنا',
      pricing: 'الأسعار',
      testimonials: 'آراء الزبناء',
      contact: 'اتصل بنا',
      langToggle: 'Français',
    },
    hero: {
      title: 'رخصة سياقتكم، أولويتنا',
      subtitle: 'تكوين عالي الجودة، نجاح مضمون. انضموا إلى مدرسة تعليم السياقة سيتي أدمينستراسيون بالرباط.',
      cta: 'تكويناتنا',
    },
    about: {
      title: 'من نحن ؟',
      subtitle: 'شريككم الموثوق لتعلم السياقة',
      p1: 'تأسست مدرسة تعليم السياقة سيتي أدمينستراسيون على مبادئ الاحترافية والبيداغوجيا، وأصبحت مرجعاً في الرباط. مهمتنا هي تكوين سائقين مسؤولين وآمنين.',
      p2: 'مع فريق من المدربين المعتمدين والمتحمسين، وأسطول من المركبات الحديثة، نوفر لكم أفضل الظروف لتعلم السياقة بكل طمأنينة.',
      stat1_val: '+10',
      stat1_label: 'سنوات من الخبرة',
      stat2_val: '95%',
      stat2_label: 'نسبة النجاح',
      stat3_val: '+2000',
      stat3_label: 'متدرب تم تكوينه',
    },
    courses: {
      title: 'تكويناتنا',
      subtitle: 'اختر الصيغة التي تناسبك',
      car: {
        title: 'رخصة السياقة صنف "ب" (السيارة)',
        description: 'تكوين شامل يتضمن دروسًا مكثفة في قانون السير ودروسًا عملية في السياقة لإتقان مركبتك.',
        features: ['20 ساعة قانون السير', '20 ساعة سياقة', 'امتحان تجريبي', 'متابعة شخصية'],
      },
      moto: {
        title: 'رخصة السياقة صنف "أ" (الدراجة النارية)',
        description: 'تعلم قيادة الدراجة النارية بأمان تام مع مدربينا المتخصصين، على الحلبة وفي حركة السير.',
        features: ['تكوين نظري', 'التحكم في المركبة', 'السياقة في حركة السير', 'توفير المعدات'],
      },
      cta: 'المزيد من التفاصيل'
    },
    pricing: {
      title: 'أسعارنا',
      subtitle: 'صيغ شفافة ومكيفة حسب احتياجاتكم',
      pack1: {
        name: 'الباقة الأساسية',
        price: '2500 درهم',
        features: ['تكوين قانون السير', '20 ساعة سياقة', 'رسوم الملف'],
        cta: 'التسجيل',
      },
      pack2: {
        name: 'باقة الراحة',
        price: '3000 درهم',
        features: ['الباقة الأساسية', '4 ساعات سياقة إضافية', 'دروس قانون السير عبر الإنترنت'],
        cta: 'التسجيل',
        popular: 'الأكثر طلبا',
      },
      pack3: {
        name: 'باقة الدراجة النارية',
        price: '2000 درهم',
        features: ['تكوين نظري خاص', '15 ساعة سياقة (حلبة وطريق)', 'رسوم الملف'],
        cta: 'التسجيل',
      },
    },
    testimonials: {
      title: 'آراء زبنائنا',
      subtitle: 'ماذا يقولون عنا',
      reviews: testimonialsAr,
    },
    contact: {
      title: 'اتصلوا بنا',
      subtitle: 'نحن في خدمتكم',
      address: 'العنوان',
      address_val: 'شارع محمد الخامس، الرباط، المغرب',
      phone: 'الهاتف',
      phone_val: '33 22 11 00 6 212+',
      email: 'البريد الإلكتروني',
      email_val: 'contact@autoecolecite.ma',
      form: {
        name: 'اسمكم الكامل',
        email: 'بريدكم الإلكتروني',
        message: 'رسالتكم',
        submit: 'إرسال الرسالة',
      },
      map_title: 'موقعنا',
    },
    footer: {
      about: 'مدرسة تعليم السياقة سيتي أدمينستراسيون ترافقكم نحو النجاح في امتحان رخصة السياقة بفضل منهجية بيداغوجية مثبتة وخدمة عالية الجودة.',
      quick_links: 'روابط سريعة',
      social_media: 'تابعونا',
      copyright: '© 2024 مدرسة تعليم السياقة سيتي أدمينستراسيون. جميع الحقوق محفوظة.',
    },
    whatsapp: {
      cta: 'تواصلوا معنا عبر واتساب!',
    }
  }
};
