
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import CoursesSection from './components/CoursesSection';
import PricingSection from './components/PricingSection';
import TestimonialsSection from './components/TestimonialsSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import { content } from './constants';
import type { Language } from './types';

function App() {
  const [lang, setLang] = useState<Language>('fr');

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const toggleLang = () => {
    setLang(prevLang => (prevLang === 'fr' ? 'ar' : 'fr'));
  };

  const currentContent = content[lang];

  return (
    <div className={`${lang === 'ar' ? 'font-arabic' : 'font-sans'} bg-secondary text-gray-800`}>
      <Header lang={lang} toggleLang={toggleLang} content={currentContent.header} />
      <main>
        <HeroSection lang={lang} content={currentContent.hero} />
        <AboutSection lang={lang} content={currentContent.about} />
        <CoursesSection lang={lang} content={currentContent.courses} />
        <PricingSection lang={lang} content={currentContent.pricing} />
        <TestimonialsSection lang={lang} content={currentContent.testimonials} />
        <ContactSection lang={lang} content={currentContent.contact} />
      </main>
      <Footer lang={lang} content={currentContent.footer} />
      <WhatsAppButton lang={lang} content={currentContent.whatsapp} />
    </div>
  );
}

export default App;
